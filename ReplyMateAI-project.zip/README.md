# ReplyMate AI
Phone-first Android project for an AI reply assistant.
Planned: floating assistant, Cute/Flirty/Funny/Cool modes, Hindi/Hinglish, voice input, user-controlled copy/paste.
Never commit an API key to this repository.
