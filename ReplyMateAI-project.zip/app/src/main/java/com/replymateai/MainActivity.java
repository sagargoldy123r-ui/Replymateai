package com.replymateai;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22),dp(28),dp(22),dp(22)); box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title=new TextView(this); title.setText("ReplyMate AI"); title.setTextSize(30); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));
        TextView info=new TextView(this); info.setText("AI reply assistant\n\nCute • Flirty • Funny • Cool • Hindi/Hinglish"); info.setTextSize(17); info.setTextColor(Color.DKGRAY); box.addView(info,new LinearLayout.LayoutParams(-1,dp(120)));
        Button overlay=new Button(this); overlay.setText("Enable floating button"); box.addView(overlay,new LinearLayout.LayoutParams(-1,dp(55)));
        overlay.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); } else Toast.makeText(this,"Permission already enabled",Toast.LENGTH_SHORT).show(); });
        TextView note=new TextView(this); note.setText("\nMessages will never be sent automatically."); note.setTextSize(14); note.setTextColor(Color.GRAY); box.addView(note,new LinearLayout.LayoutParams(-1,dp(70)));
        setContentView(box);
    }
}
